
import java.io.File;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.shape.Polyline;
public class Quiz_LAB extends Application {
  @Override // Override the start method in the Application class
  public void start(Stage firstStage) {
	  //Create a Pane
     
         
     //stage.close

	  Pane pane = new Pane();
	  pane.setPadding(new Insets(50, 75, 75, 50));
	  
	  // Create StackPane
	  StackPane sp = new StackPane();
	  sp.setPadding(new Insets(50, 50, 50, 50));
	  
	  // Create FlowPane
	  FlowPane fp = new FlowPane();
	  fp.setPadding(new Insets(11, 12, 13, 14));
	  fp.setHgap(5);
	  fp.setVgap(5);
	  
	  // Create GridPane
	  GridPane gp = new GridPane();
	  gp.setPadding(new Insets(100, 100, 100, 100));
	  gp.setVgap(5); 
	  gp.setHgap(5); 
	  gp.setAlignment(Pos.CENTER);
	  
	  // Create BorderPane
	  BorderPane bp = new BorderPane();
	  bp.setPadding(new Insets(10, 10, 10, 10));
	  
	  // Create HBox
	  HBox hb = new HBox();
	  hb.setPadding(new Insets(10, 10, 10, 10));
	  
	  // Create VBox
	  VBox vb = new VBox();
	  vb.setPadding(new Insets(1, 1, 1, 1));
	  
	  // Create text to place in Pane3
	  	  
	  // Create and place nodes in FlowPane
	  fp.getChildren().addAll(new Label("Red Pill:"), new TextField(), new Label("MI:"));
	  TextField tf1 = new TextField();
	  tf1.setPrefColumnCount(1);
	  fp.getChildren().addAll(tf1, new Label("Blue Pill:"), new TextField());
	  
	  // Create and place nodes in GridPane
	  gp.add(new Label("Super Speed:"), 0, 0);
	  gp.add(new TextField(), 1, 0);
	  gp.add(new Label("Live a Thousand Years"), 0, 1); 
	  gp.add(new TextField(), 1, 1);
	  gp.add(new Label("Become liquid:"), 0, 2);
	  gp.add(new TextField(), 1, 2);
	  Button btn = new Button("Add Name");
	  gp.add(btn, 1, 3);
	  gp.setHalignment(btn, HPos.RIGHT);
	  
	  // Create and place nodes in BorderPane
	  bp.setTop(new TextField("Top")); 
	  bp.setBottom(new TextField("Bottom")); 
	  bp.setLeft(new TextField("Left")); 
	  bp.setRight(new TextField("Right")); 
	  bp.setCenter(new TextField("Center")); 
	  Text text1 = new Text("Text, circle, lines, and color");
	  text1.setY(50);
	  text1.setX(230);
	  text1.setFont(Font.font("Courier", FontWeight.BOLD, FontPosture.ITALIC, 15));
	  pane.getChildren().add(text1);
	  
	  // Create circle to place in Pane3
	  Circle circle = new Circle();
	  circle.centerXProperty().bind(pane.widthProperty().divide(2));
	  circle.centerYProperty().bind(pane.heightProperty().divide(2));
	  circle.setRadius(100);
	  circle.setStroke(Color.RED); 
	  circle.setFill(Color.BLACK);
	  pane.getChildren().add(circle);
	  
	  // Create lines to place in Pane3
	  Line line1 = new Line(10, 8, 15, 15);
	  line1.endXProperty().bind(pane.widthProperty().subtract(10));
	  line1.endYProperty().bind(pane.heightProperty().subtract(10));
	  line1.setStrokeWidth(5);
	  line1.setStroke(Color.BLUE);
	  pane.getChildren().add(line1);
	  Line line2 = new Line(10, 10, 10, 10);
	  line2.startXProperty().bind(pane.widthProperty().subtract(10));
	  line2.endYProperty().bind(pane.heightProperty().subtract(10));
	  line2.setStrokeWidth(5);
	  line2.setStroke(Color.RED);
	  pane.getChildren().add(line2);
	  
	  // Create and place nodes in StackPane
	  Rectangle r1 = new Rectangle(25, 10, 100, 200);
	  Rectangle r2 = new Rectangle(25, 10, 200, 100);
	  r1.setStroke(Color.BLUE);
	  r1.setFill(Color.RED);
	  r2.setStroke(Color.BLACK);
	  r2.setFill(Color.WHITE);
	  sp.getChildren().addAll(r1, r2);

	   //Create image to place in HBox
	  Image image = new Image("File:vongola.jpg");
	  hb.getChildren().add(new ImageView(image));
	  
	  // Create node to place in VBox
	  Arc arc = new Arc(150, 215, 90, 200, 30 + 190, 35);
	  Arc arc2 = new Arc(300, 100, 180, 60, 20 + 190, 70);
	  Arc arc3 = new Arc(300, 100, 180, 90, 60 + 180, 70);
	  arc.setFill(Color.BLUE);
	  arc.setType(ArcType.OPEN);
	  arc.setStroke(Color.GREEN);
	  arc2.setFill(Color.RED);
	  arc2.setType(ArcType.ROUND);
	  arc2.setStroke(Color.RED);
	  arc3.setFill(Color.BLUE);
	  arc3.setType(ArcType.ROUND);
	  arc3.setStroke(Color.BLACK);
	  vb.getChildren().addAll(arc, arc2, arc3);
     //*********************************************************
     
     HBox Menu = new HBox();
     Stage s0 = new Stage();
     Button btn1 = new Button("Ellipse");
     btn1.setOnAction(e ->firstStage.show());
     Menu.getChildren().addAll(btn1);
	  s0.setTitle("Menu");
	  s0.setScene(new Scene(Menu, 770,30));
     s0.show();
     
     
	  ///****************************************************
     //FirstStage
	  Scene sc1 = new Scene(new Ellipse1(), 500, 200);
	  firstStage.setTitle("Pane with Ellipse");
	  firstStage.setScene(sc1);
     
	  //****************************************************
	  //Stage 1
	  Stage s1 = new Stage();
	  s1.setTitle("Pane of Circle, Lines, and Text");
	  s1.setScene(new Scene(pane));
	  Button btn2 = new Button("Pane of Circle, Lines, and Text");
     btn2.setOnAction(e -> s1.show());
     Menu.getChildren().addAll(btn2);
     
     //****************************************************
	  //Stage 2
	  Stage s2 = new Stage();
	  s2.setTitle(" Rectangles");
	  s2.setScene(new Scene(sp));
     Button btn3 = new Button("Rectangles");
     btn3.setOnAction(e-> s2.show());  
     Menu.getChildren().addAll(btn3);
     
	  //***************************************************
     //Stage 3
     Stage s3 = new Stage();
	  s3.setTitle("Textfields");
	  s3.setScene(new Scene(fp, 200, 250));
     Button btn4 = new Button("Textfields");
     btn4.setOnAction(e-> s3.show());  
     Menu.getChildren().addAll(btn4);
     
     //***************************************************
	  //Stage 4
	  Stage s4 = new Stage();
	  s4.setTitle("GridPane");
	  s4.setScene(new Scene(gp));
	  Button btn5 = new Button("GridPane");
     btn5.setOnAction(e-> s4.show());  
     Menu.getChildren().addAll(btn5);
     
    //***************************************************
    //Stage 5	  
	  Stage s5 = new Stage();
	  s5.setTitle("BorderPane");
	  s5.setScene(new Scene(bp, 400, 400));
	  Button btn6 = new Button("BorderPane");
     btn6.setOnAction(e-> s5.show());  
     Menu.getChildren().addAll(btn6);	
       
	  //************************************************
     //Stage 6
     Stage s6 = new Stage();
	  s6.setTitle("HBox with Image");
	  s6.setScene(new Scene(hb));
	  Button btn7 = new Button("Image");
     btn7.setOnAction(e-> s6.show());  
     Menu.getChildren().addAll(btn7);
     
     //************************************************
     //Stage 7	 
	  Stage s7 = new Stage();
	  s7.setTitle("Pane with Polygon");
	  s7.setScene(new Scene(new MyPolygon1(), 400, 300));
	  Button btn8 = new Button("Polygon");
     btn8.setOnAction(e-> s7.show());  
     Menu.getChildren().addAll(btn8);
     
     //*******************************************************
     //Stage8    
	  Stage s8 = new Stage();
	  s8.setTitle("VBox with Arcs: Open, Chord, Round");
	  s8.setScene(new Scene(vb, 400, 300));
	  Button btn9 = new Button("VBox with Arcs");
     btn9.setOnAction(e-> s8.show());  
     Menu.getChildren().addAll(btn9);
     
     //********************************************
     //Stage 9 
      Stage s9 =new Stage();
      Polyline polyline = new Polyline();  
      polyline.getPoints().addAll(new Double[]{        
         200.0, 50.0, 
         400.0, 50.0, 
         450.0, 150.0,          
         400.0, 250.0, 
         200.0, 250.0,                   
         150.0, 150.0, 
      }); 
      Group root = new Group(polyline);  
      Scene scene = new Scene(root, 600, 300);  
      s9.setTitle("Drawing a Polyline"); 
      s9.setScene(scene);  
      Button btn10 = new Button("Polyline");
      btn10.setOnAction(e-> s9.show());  
      Menu.getChildren().addAll(btn10);
   
  }//*************************************************************
  
  public static void main(String[] args) { 
    launch(args);
  }
}

class Ellipse1 extends Pane {
	private void paint() {
		getChildren().clear();
	    for (int i = 0; i < 16; i++) {
	      // Create an ellipse and add it to pane
	      Ellipse e1 = new Ellipse(getWidth() / 2, getHeight() / 2, getWidth() / 2 - 50, getHeight() / 2 - 50);
	      e1.setStroke(Color.color(Math.random(), Math.random(), Math.random()));
	      e1.setFill(Color.WHITE);
	      e1.setRotate(i * 180 / 16);
	      getChildren().add(e1);
	    }
	}
	  
	@Override
	public void setWidth(double width) {
		super.setWidth(width);
		paint();
	}
	  
	@Override
	public void setHeight(double height) {
		super.setHeight(height);
	    paint();
	}
}

class MyPolygon1 extends Pane {
	  private void paint() {
	    // Create a polygon and place polygon to pane
	    Polygon polygon = new Polygon();
	    polygon.setFill(Color.BLUE);
	    polygon.setStroke(Color.RED);
	    ObservableList<Double> list = polygon.getPoints();
	    
	    double centerX = getWidth() / 2, centerY = getHeight() / 2;
	    double radius = Math.min(getWidth(), getHeight()) * 0.4;

	    // Add points to the polygon list
	    for (int i = 0; i < 6; i++) {
	      list.add(centerX + radius * Math.cos(2 * i * Math.PI / 6)); 
	      list.add(centerY - radius * Math.sin(2 * i * Math.PI / 6));
	    }     
	    
	    getChildren().clear();
	    getChildren().add(polygon); 
	  }
	  
	  @Override
	  public void setWidth(double width) {
	    super.setWidth(width);
	    paint();
	  }
	  
	  @Override
	  public void setHeight(double height) {
	    super.setHeight(height);
	    paint();
	  }
}